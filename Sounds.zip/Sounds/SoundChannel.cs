namespace Box.Sounds;

/// <summary>
/// Represents a sound channel used by the sound manager, allowing you to set up multiple channels for music, sound effects, ambient sounds, etc.
/// </summary>
/// <remarks>
/// Note: The SoundChannel ID of zero is reserved for the master channel. The master channel can adjust audio levels across all channels.
/// </remarks>
public sealed class SoundChannel
{
    // Keep track of sounds that are being used. It can contain multiple of the same sound
    private readonly List<SoundInstance> _sounds = new(), _removedSounds = new(), _addSounds = new();
    private readonly CoroutineHandle _handle;
    private readonly bool _isBlocking;
    private float _volume = 1.0f, _pitch = 1.0f;
    private bool _forceStop;

    internal bool _isMasterChannel;
    internal int _id = -1;

    /// <summary>
    /// The total number of currently playing audio instances.
    /// </summary>
    public int Count => _sounds.Count;

    /// <summary>
    /// This audio identifier. Id zero is reserved for the master channel.
    /// </summary>
    public int Id => _id;

    /// <summary>
    /// A blocking channel is primarily used for music, allowing you to fade out the old audio and fade in new audio.
    /// </summary>
    /// <remarks>
    /// Note: It ensures that only one audio track is played at a time by fading out the previous sound instance.
    /// </remarks>
    public bool IsBlocking => _isBlocking;

    /// <summary>
    /// Indicates if this is the master channel.
    /// </summary>
    public bool IsMasterChannel => _isMasterChannel;

    /// <summary>
    /// Adjusts the pitch of the channel audio to make it deeper or higher.
    /// </summary>
    /// <remarks>
    /// Acceptable values range from -2.0 to 2.0.
    /// </remarks>
    public float Pitch
    {
        get => _pitch;
        set
        {
            float oldValue = _pitch;
            _pitch = Math.Clamp(value, -2, 2f);

            if (_pitch != oldValue)
            {
                foreach (var sound in _sounds.ToList())
                {
                    var item = sound;

                    if (item.State != SoundState.Playing)
                        continue;
                    if (_removedSounds.Contains(item))
                        continue;
                    if (_addSounds.Contains(item))
                        continue;

                    // Usually used for music, not really cared for soundfx since the
                    // volume can be adjusted when you play an sound thru sound manager.
                    item.Pitch = _pitch;
                }

                Signal.Instance.Emit(EngineSignals.SoundChannelPitchChanged, this);
            }
        }
    }

    /// <summary>
    /// Sets the audio level of the specified channel.
    /// </summary>
    /// <remarks>
    /// Note: This level is also influenced by the master volume setting.
    /// <para>Acceptable values range from 0.0 to 1.0.</para>
    /// </remarks>
    public float Volume
    {
        get => _volume;
        set
        {
            float oldVolume = _volume;
            _volume = Math.Clamp(value, 0f, 1f);

            if (_volume != oldVolume)
            {
                SoundChannel master = SoundManager.Instance.Get(0);

                foreach (var sound in _sounds.ToList())
                {
                    var item = sound;

                    if (item.State != SoundState.Playing)
                        continue;
                    if (_removedSounds.Contains(item))
                        continue;
                    if (_addSounds.Contains(item))
                        continue;

                    // Usually used for music, not really cared for soundfx since the
                    // volume can be adjusted when you play an sound thru sound manager.
                    item.Volume = _volume * master.Volume;
                }

                Signal.Instance.Emit(EngineSignals.SoundChannelVolumeChanged, this);
            }
        }
    }


    /// <summary>
    /// Gets a list of currently playing sound instances.
    /// </summary>
    public IEnumerable<SoundInstance> Sounds
    {
        get
        {
            if (_sounds.Count == 0)
                yield break;

            for (int i = 0; i < _sounds.Count; i++)
            {
                if (_sounds[i].State != SoundState.Playing)
                    continue;

                yield return _sounds[i];
            }
        }
    }

    internal SoundChannel(float volume, float pitch, bool isBlocking)
    {
        _isBlocking = isBlocking;
        _volume = Math.Clamp(volume, 0f, 1f);
        _pitch = Math.Clamp(pitch, -2f, 2f);
        _handle = Coroutine.Instance.Run(UpdateSounds());

        // Required for master channel to update volume of other channels:
        Signal.Instance.Connect(EngineSignals.SoundChannelVolumeChanged, OnAudioChannelVolumeChanged);
    }

    /// <summary>
    /// Represents a sound channel used by the sound manager, allowing setup of multiple channels
    /// for music, sound effects, ambient sounds, etc.
    /// </summary>
    ~SoundChannel()
    {
        Coroutine.Instance.Stop(_handle);

        // Required for master channel to update volume of other channels:
        Signal.Instance.Disconnect(EngineSignals.SoundChannelVolumeChanged, OnAudioChannelVolumeChanged);
    }

    // Required for master channel to update volume of other channels:
    private void OnAudioChannelVolumeChanged(SignalHandle handle)
    {
        // if this is master channel, no need to re-addjust again.
        if (_id == 0)
            return;

        SoundChannel master = SoundManager.Instance.Get(0);

        foreach (var sound in _sounds.ToList())
        {
            var item = sound;

            if (item.State != SoundState.Playing)
                continue;
            if (_removedSounds.Contains(item))
                continue;
            if (_addSounds.Contains(item))
                continue;

            // Usually used for music, not really cared for soundfx since the
            // volume can be adjusted when you play an sound thru sound manager.
            item.Volume = _volume * master.Volume;
        }
    }

    internal SoundInstance Add(Sound sound, float? volume, float? pitch)
    {
        SoundInstance instance;

        if (!_isBlocking)
        {
            var master = SoundManager.Instance.Get(0);
            instance = sound.CreateInstance();

            instance.Volume = (volume ?? _volume) * master.Volume;
            instance.Pitch = pitch ?? 1f;
            instance.Play();

            _sounds.Add(instance);
        }
        else
        {
            if (IsAlreadyPlaying(sound))
                return default;

            instance = sound.CreateInstance();

            instance.Volume = 0f;
            instance.Pitch = pitch ?? 1f;
            instance.Play();

            _addSounds.Add(instance);

            if (_sounds.Count > 0)
            {
                var oldSound = _sounds.First();

                _removedSounds.Add(oldSound);
                _sounds.Clear();

                if (fadeRoutine.IsRunning)
                {
                    if (_removedSounds.Count > 1)
                        _removedSounds.Last().Stop();

                    fadeRoutine.Stop();
                }

                fadeRoutine = Coroutine.Instance.Run(FadeMusicSounds(oldSound, instance, _volume));
            }
            else
            {
                fadeRoutine = Coroutine.Instance.Run(FadeSingleMusicSound(instance, _volume, direction: 1));
            }
        }

        Signal.Instance.Emit(EngineSignals.SoundStarted, this, sound);

        return instance;
    }

    private CoroutineHandle fadeRoutine;


    internal bool IsAlreadyPlaying(Sound sound)
    {
        var a = _sounds.Any(x => x._sound == sound);
        var c = _addSounds.Any(x => x._sound == sound);
        var b = _removedSounds.Any(x => x._sound == sound);

        return a || b;// || c;
    }

    internal void Remove(Sound sound)
    {
        IEnumerator Routine(Sound sound)
        {
            if (!_sounds.Any(x => x._sound == sound))
                yield break;

            if (!_isBlocking)
            {
                if (!_forceStop)
                {
                    while (_removedSounds.Any(x => x._sound == sound))
                        yield return null;

                    while (_addSounds.Any(x => x._sound == sound))
                        yield return null;
                }

                var items = _sounds.Where(x => x._sound == sound);

                if (items.IsEmpty())
                    yield break;

                foreach (var item in items.ToList())
                {
                    if (item.State == SoundState.Playing)
                        item.Stop();

                    _sounds.Remove(item);
                }
            }
            else
            {
                var item = _sounds.FirstOrDefault(x => x._sound == sound);

                if (item.IsEmpty)
                    yield break;

                _removedSounds.AddRange(_sounds);
                _sounds.Clear();

                Coroutine.Instance.Run(FadeSingleMusicSound(item, _volume, direction: -1));
            }

            Signal.Instance.Emit(EngineSignals.SoundRemoved, this, sound);
        }

        Coroutine.Instance.Run(Routine(sound));
    }

    internal void Clear(bool forceStop)
    {
        if (_sounds.Count == 0)
            return;

        _forceStop = forceStop;

        foreach (var sound in _sounds.ToList())
        {
            if (sound.State == SoundState.Playing)
                sound.Stop();

            Remove(sound._sound);
        }
    }

    private IEnumerator FadeSingleMusicSound(SoundInstance sound, float desiredVolume, float direction = -1)
    {
        SoundChannel master = SoundManager.Instance.Get(0);

        while (true)
        {
            if (direction < 0 && sound.Volume == 0f)
                break;
            if (direction > 0 && sound.Volume == desiredVolume * master.Volume)
                break;

            sound.Volume = Vect2.MoveTowards(sound.Volume, direction < 0 ? 0f : desiredVolume * master.Volume, Clock.Instance.DeltaAsSeconds * EngineSettings.Instance.AudioSpeed);

            yield return null;
        }

        if (direction < 0)
            sound.Stop();
        else
            _sounds.Add(sound);

        _addSounds.Clear();
        _removedSounds.Clear();
    }

    private IEnumerator FadeMusicSounds(SoundInstance oldSound, SoundInstance newSound, float desiredVolume)
    {
        SoundChannel master = SoundManager.Instance.Get(0);

        while (true)
        {
            if (oldSound.Volume == 0f && newSound.Volume == (desiredVolume * master.Volume))
                break;

            oldSound.Volume = Vect2.MoveTowards(oldSound.Volume, 0f, Clock.Instance.DeltaAsSeconds * EngineSettings.Instance.AudioSpeed);
            newSound.Volume = Vect2.MoveTowards(newSound.Volume, desiredVolume * master.Volume, Clock.Instance.DeltaAsSeconds * EngineSettings.Instance.AudioSpeed);

            yield return null;
        }

        oldSound.Stop();

        _sounds.Add(newSound);

        _removedSounds.Clear();
        _addSounds.Clear();
    }

    private IEnumerator UpdateSounds()
    {
        while (true) // Loop forever
        {
            while (_sounds.Count == 0)
                yield return null;

            for (int i = _sounds.Count - 1; i >= 0; i--)
            {
                if (i > _sounds.Count - 1)
                    break;

                var current = _sounds[i];

                // We store sound effects to keep track of what is playing, but
                // we don't really care about the sound effects themselves. However, we do need to
                // clear sound effects from the channel sound cache.
                //
                // For music effects, we need to keep track of when they finish playing and 
                // repeat them. We don't use the "Play" function because it may reset the volumes, 
                // so we use the "Repeat" function to maintain the current audio state.
                if (current.State != SoundState.Playing)
                {
                    if (_isBlocking)
                    {
                        if (_removedSounds.Contains(current))
                            continue;

                        if (!_forceStop)
                            current.Repeat();
                    }
                    else
                    {
                        // We make sure to clear up any sound effects
                        _sounds.Remove(current);
                        i--;
                    }
                }

                // Dont remove: it will lock up:
                yield return null;
            }
        }
    }
}
