namespace Box.Sounds;

/// <summary>
/// Represents an instance of a sound playing or managed within an application.
/// </summary>
public struct SoundInstance
{
    internal readonly Sound _sound;
    private readonly SFMLSoundInstance _instance;
    private float _volume = 1.0f, _pitch = 1f;

    /// <summary>
    /// 
    /// </summary>
    public readonly Sound Sound => _sound;

    /// <summary>
    /// Gets the current state of the sound instance.
    /// </summary>
    public readonly SoundState State => (SoundState)_instance.Status;

    /// <summary>
    /// Gets the total duration of the sound.
    /// </summary>
    public readonly TimeSpan Length => _sound._buffer.Duration.ToTimeSpan();

    /// <summary>
    /// Gets the current playback position of the sound.
    /// </summary>
    public readonly TimeSpan Position => _instance.Status == SFML.Audio.SoundStatus.Playing
        ? _instance.PlayingOffset.ToTimeSpan() : TimeSpan.Zero;

    /// <summary>
    /// Gets a value indicating whether the sound instance is empty or uninitialized.
    /// </summary>
    public readonly bool IsEmpty => _sound.IsEmpty || _sound._buffer is null || _instance is null;

    /// <summary>
    /// Gets or sets the volume of the sound instance.
    /// </summary>
    public float Volume
    {
        readonly get => _volume;
        set
        {
            _volume = Math.Clamp(value, 0f, 1f);

            if (_instance.Status == SFML.Audio.SoundStatus.Playing)
                _instance.Volume = Math.Clamp(_volume * 100f, 0f, 100f);
        }
    }

    /// <summary>
    /// Gets or sets the pitch of the sound instance.
    /// </summary>
    public float Pitch
    {
        readonly get => _pitch;
        set
        {
            _pitch = Math.Clamp(value, -2f, 2f);

            if (_instance.Status == SFML.Audio.SoundStatus.Playing)
                _instance.Pitch = Math.Clamp(_pitch, -2f, 2f);
        }
    }

    internal SoundInstance(Sound sound)
    {
        _sound = sound;

        _instance = new SFMLSoundInstance(_sound._buffer)
        {
            // Always set volume to zero at the start so it doesnt blerp 
            // to max volume than to sound manager volume
            Volume = 0f
        };
    }

    /// <summary>
    /// Plays the sound instance from its current position.
    /// </summary>
    public readonly void Play()
    {
        if (_instance.Status != SFML.Audio.SoundStatus.Stopped)
            return;

        _instance.Pitch = Math.Clamp(_pitch, -2f, 2f);
        _instance.Volume = Math.Clamp(_volume * 100f, 0f, 100f);

        _instance.Play();
    }

    /// <summary>
    /// Restarts the sound instance from the beginning when it reaches the end.
    /// </summary>
    public readonly void Repeat()
    {
        if (_instance.Status != SFML.Audio.SoundStatus.Stopped)
            return;

        _instance.Play();
    }

    /// <summary>
    /// Stops the sound instance playback.
    /// </summary>
    public readonly void Stop()
    {
        if (_instance.Status != SFML.Audio.SoundStatus.Playing)
            return;

        _instance?.Stop();
        _instance?.Dispose();
    }
}
