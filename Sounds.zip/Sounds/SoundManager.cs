namespace Box.Sounds;

/// <summary>
/// The sound manager handles all sound channels, allowing you to manage music, sound effects, and other audio effects.
/// </summary>
public sealed class SoundManager
{

    #region Fields
    private readonly Dictionary<int, SoundChannel> _channels = new();

    private static SoundManager _instance;
    #endregion


    #region Properties
    /// <summary>
    /// Singleton instance of the sound manager.
    /// </summary>
    public static SoundManager Instance => _instance;

    /// <summary>
    /// Total number of sound channels managed by the sound manager.
    /// </summary>
    public int ChannelCount => _channels.Sum(x => x.Value.Count);

    /// <summary>
    /// Total count of currently playing sound instances across all channels.
    /// </summary>
    public int PlayCount => _channels.Sum(x => x.Value.Count);
    #endregion


    #region Constructor

    internal SoundManager()
    {
        _instance ??= this;

        // Add master channel:
        _channels.Add(0, new SoundChannel(1f, 1f, false) { _isMasterChannel = true, _id = 0 });
    }
    #endregion


    #region Add
    /// <summary>
    /// Adds a new audio channel for music, sound effects, or other types as needed.
    /// </summary>
    /// <param name="id">The ID of the channel.</param>
    /// <param name="volume">The initial volume of the channel, ranging from 0.0 to 1.0.</param>
    /// <param name="pitch">The initial pitch of the channel, ranging from -2.0 to 2.0.</param>
    /// <param name="isBlocking">Specifies if the channel is blocking, meaning it only accepts one audio instance at a time (typically used for music channels).</param>
    /// <exception cref="ArgumentException">Thrown if attempting to add to channel zero, which is reserved for the master channel.</exception>
    /// <exception cref="InvalidOperationException">Thrown if the channel ID already exists.</exception>
    public void Add(int id, float volume = 1.0f, float pitch = 1.0f, bool isBlocking = false)
    {
        if (id == 0)
            throw new ArgumentException($"Cannot use ID '{id}', as it is reserved for the Master Audio Channel.", nameof(id));

        if (Exists(id))
            throw new InvalidOperationException($"A sound channel with ID '{id}' already exists.");

        _channels.Add(id, new SoundChannel(volume, pitch, isBlocking)
        {
            _isMasterChannel = false,
            _id = id
        });
    }

    /// <summary>
    /// Adds a new audio channel for music, sound effects, or other types as needed.
    /// </summary>
    /// <param name="id">The ID of the channel.</param>
    /// <param name="volume">The initial volume of the channel, ranging from 0.0 to 1.0.</param>
    /// <param name="pitch">The initial pitch of the channel, ranging from -2.0 to 2.0.</param>
    /// <param name="isBlocking">Specifies if the channel is blocking, meaning it only accepts one audio instance at a time (typically used for music channels).</param>
    /// <exception cref="ArgumentException">Thrown if attempting to add to channel zero, which is reserved for the master channel.</exception>
    /// <exception cref="InvalidOperationException">Thrown if the channel ID already exists.</exception>
    public void Add(Enum id, float volume = 1.0f, float pitch = 1.0f, bool isBlocking = false)
        => Add(Convert.ToInt32(id), volume, pitch, isBlocking);
    #endregion


    #region Remove
    /// <summary>
    /// Removes an audio channel that was previously added.
    /// </summary>
    /// <param name="id">The ID of the channel to remove.</param>
    /// <returns>True if the sound channel was successfully removed; false otherwise. Removal will fail automatically if attempting to remove the master channel (ID zero).</returns>
    public bool Remove(int id)
    {
        if (!Exists(id))
            return false;
        if (id == 0)
            return false;

        if (_channels.Remove(id))
        {
            _channels[id].Clear(false);

            return true;
        }

        return false;
    }

    /// <summary>
    /// Removes an audio channel that was previously added.
    /// </summary>
    /// <param name="id">The ID of the channel to remove.</param>
    /// <returns>True if the sound channel was successfully removed; false otherwise. Removal will fail automatically if attempting to remove the master channel (ID zero).</returns>
    public bool Remove(Enum id) => Remove(Convert.ToInt32(id));
    #endregion


    #region Clear
    /// <summary>
    /// Removes all sound channels except the master channel, along with any playing sound instances on those channels.
    /// </summary>
    public void Clear()
    {
        if (_channels.Count == 0)
            return;

        foreach (var channel in _channels)
        {
            if (channel.Value.IsMasterChannel)
                continue;

            Remove(channel.Key);
        }
    }
    #endregion


    #region Exists
    /// <summary>
    /// Checks if the specified channel exists.
    /// </summary>
    /// <param name="id">The ID of the channel to check.</param>
    /// <returns>True if the channel exists; false otherwise.</returns>
    public bool Exists(int id) => _channels.ContainsKey(id);

    /// <summary>
    /// Checks if the specified channel exists.
    /// </summary>
    /// <param name="id">The ID of the channel to check.</param>
    /// <returns>True if the channel exists; false otherwise.</returns>
    public bool Exists(Enum id) => Exists(Convert.ToInt32(id));
    #endregion


    #region Get
    /// <summary>
    /// Retrieves the sound channel based on the channel ID.
    /// </summary>
    /// <param name="id">The ID of the channel to retrieve.</param>
    /// <returns>The sound channel object if the channel ID exists; otherwise, returns null.</returns>
    public SoundChannel Get(int id)
    {
        if (!Exists(id))
            return null;

        return _channels[id];
    }

    /// <summary>
    /// Retrieves the sound channel based on the channel ID.
    /// </summary>
    /// <param name="id">The ID of the channel to retrieve.</param>
    /// <returns>The sound channel object if the channel ID exists; otherwise, returns null.</returns>
    public SoundChannel Get(Enum id) => Get(Convert.ToInt32(id));

    /// <summary>
    /// Tries to retrieve the sound channel based on the channel ID.
    /// </summary>
    /// <param name="id">The ID of the channel to retrieve.</param>
    /// <param name="channel">Outputs the sound channel if found.</param>
    /// <returns>True if the channel was found and retrieved successfully; otherwise, false.</returns>
    public bool TryGet(int id, out SoundChannel channel)
    {
        channel = Get(id);

        return channel is not null;
    }

    /// <summary>
    /// Tries to retrieve the sound channel based on the channel ID.
    /// </summary>
    /// <param name="id">The ID of the channel to retrieve.</param>
    /// <param name="channel">Outputs the sound channel if found.</param>
    /// <returns>True if the channel was found and retrieved successfully; otherwise, false.</returns>
    public bool TryGet(Enum id, out SoundChannel channel) => TryGet(Convert.ToInt32(id), out channel);
    #endregion


    #region Play
    /// <summary>
    /// Plays a sound on the specified channel ID.
    /// </summary>
    /// <remarks>
    /// Note: Setting volume or pitch will override the channel's volume and pitch settings.
    /// </remarks>
    /// <param name="id">The ID of the channel to play the sound.</param>
    /// <param name="sound">The sound to play.</param>
    /// <param name="volume">The volume at which to play the sound (0.0 to 1.0).</param>
    /// <param name="pitch">The pitch at which to play the sound (-2.0 to 2.0).</param>
    public void Play(int id, Sound sound, float volume, float pitch)
    {
        if (!Exists(id))
            return;

        _channels[id].Add(sound, volume, pitch);
    }

    /// <summary>
    /// Plays a sound on the specified channel ID.
    /// </summary>
    /// <remarks>
    /// Note: Setting volume will override the channel's volume settings.
    /// </remarks>
    /// <param name="id">The ID of the channel to play the sound.</param>
    /// <param name="sound">The sound to play.</param>
    /// <param name="volume">The volume at which to play the sound (0.0 to 1.0).</param>
    public void Play(int id, Sound sound, float volume)
    {
        if (!Exists(id))
            return;

        _channels[id].Add(sound, volume, null);
    }

    /// <summary>
    /// Plays a specified sound on the identified channel.
    /// </summary>
    /// <param name="id">The unique ID of the channel where the sound will be played.</param>
    /// <param name="sound">The sound asset to be played.</param>
    public void Play(int id, Sound sound)
    {
        if (!Exists(id))
            return;

        _channels[id].Add(sound, null, null);
    }

    /// <summary>
    /// Plays a sound on the specified channel ID.
    /// </summary>
    /// <remarks>
    /// Setting `blocking` to true will override the channel's default behavior, allowing only one audio instance at a time (typically used for music channels).
    /// </remarks>
    /// <param name="id">The ID of the channel to play the sound.</param>
    /// <param name="sound">The sound to play.</param>
    /// <param name="blocking">Specifies whether the channel should block, allowing only one audio instance at a time.</param>
    public void Play(int id, Sound sound, bool blocking)
    {
        if (!Exists(id))
            return;
        if (blocking && _channels[id].Sounds.Any(x => x._sound == sound))
            return;

        _channels[id].Add(sound, null, null);
    }

    /// <summary>
    /// Plays a sound on the specified channel ID.
    /// </summary>
    /// <remarks>
    /// <para>Note: Setting "blocking" to true will override the channel's blocking settings, allowing only one audio instance at a time (typically used for music channels).</para>
    /// <para>Note: Setting "volume" will override the channel's volume settings.</para>
    /// </remarks>
    /// <param name="id">The ID of the channel to play the sound.</param>
    /// <param name="sound">The sound to play.</param>
    /// <param name="volume">The volume at which to play the sound (0.0 to 1.0).</param>
    /// <param name="blocking">Specifies whether the channel should block, allowing only one audio instance at a time.</param>
    public void Play(int id, Sound sound, float volume, bool blocking)
    {
        if (!Exists(id))
            return;
        if (blocking && _channels[id].Sounds.Any(x => x._sound == sound))
            return;

        _channels[id].Add(sound, volume, null);
    }

    /// <summary>
    /// Plays a sound on the specified channel ID.
    /// </summary>
    /// <remarks>
    /// Note: Setting volume or pitch will override the channel's volume and pitch settings.
    /// </remarks>
    /// <param name="id">The ID of the channel to play the sound.</param>
    /// <param name="sound">The sound to play.</param>
    /// <param name="volume">The volume at which to play the sound (0.0 to 1.0).</param>
    /// <param name="pitch">The pitch at which to play the sound (-2.0 to 2.0).</param>
    public void Play(Enum id, Sound sound, float volume, float pitch)
    {
        Play(Convert.ToInt32(id), sound, volume, pitch);
    }

    /// <summary>
    /// Plays a sound on the specified channel ID.
    /// </summary>
    /// <remarks>
    /// Note: Setting volume will override the channel's volume settings.
    /// </remarks>
    /// <param name="id">The ID of the channel to play the sound.</param>
    /// <param name="sound">The sound to play.</param>
    /// <param name="volume">The volume at which to play the sound (0.0 to 1.0).</param>
    public void Play(Enum id, Sound sound, float volume)
    {
        Play(Convert.ToInt32(id), sound, volume);
    }

    /// <summary>
    /// Plays a sound on the specified channel ID.
    /// </summary>
    /// <remarks>
    /// Setting `blocking` to true will override the channel's default behavior, allowing only one audio instance at a time (typically used for music channels).
    /// </remarks>
    /// <param name="id">The ID of the channel to play the sound.</param>
    /// <param name="sound">The sound to play.</param>
    /// <param name="blocking">Specifies whether the channel should block, allowing only one audio instance at a time.</param>
    public void Play(Enum id, Sound sound, bool blocking)
    {
        Play(Convert.ToInt32(id), sound, blocking);
    }

    /// <summary>
    /// Plays a sound on the specified channel ID.
    /// </summary>
    /// <remarks>
    /// <para>Note: Setting "blocking" to true will override the channel's blocking settings, allowing only one audio instance at a time (typically used for music channels).</para>
    /// <para>Note: Setting "volume" will override the channel's volume settings.</para>
    /// </remarks>
    /// <param name="id">The ID of the channel to play the sound.</param>
    /// <param name="sound">The sound to play.</param>
    /// <param name="volume">The volume at which to play the sound (0.0 to 1.0).</param>
    /// <param name="blocking">Specifies whether the channel should block, allowing only one audio instance at a time.</param>
    public void Play(Enum id, Sound sound, float volume, bool blocking)
    {
        Play(Convert.ToInt32(id), sound, volume, blocking);
    }

    /// <summary>
    /// Plays a specified sound on the identified channel.
    /// </summary>
    /// <param name="id">The unique ID of the channel where the sound will be played.</param>
    /// <param name="sound">The sound asset to be played.</param>
    public void Play(Enum id, Sound sound)
    {
        Play(Convert.ToInt32(id), sound);
    }
    #endregion


    #region Stop
    /// <summary>
    /// Stops a specific sound on the identified channel.
    /// </summary>
    /// <param name="id">The unique ID of the channel where the sound will be stopped.</param>
    /// <param name="sound">The sound instance to be stopped.</param>
    public void Stop(int id, Sound sound)
    {
        if (!Exists(id))
            return;

        _channels[id].Remove(sound);
    }

    /// <summary>
    /// Stops a specific sound on the identified channel.
    /// </summary>
    /// <param name="id">The unique ID of the channel where the sound will be stopped.</param>
    /// <param name="sound">The sound instance to be stopped.</param>
    public void Stop(Enum id, Sound sound)
    {
        Stop(Convert.ToInt32(id), sound);
    }

    /// <summary>
    /// Stops all audio playback on the specified channel ID.
    /// </summary>
    /// <param name="id">The unique ID of the channel where all sounds will be stopped.</param>
    public void Stop(int id)
    {
        if (!Exists(id))
            return;

        _channels[id].Clear(false);
    }

    /// <summary>
    /// Stops all audio playback on the specified channel ID.
    /// </summary>
    /// <param name="id">The unique ID of the channel where all sounds will be stopped.</param>
    public void Stop(Enum id)
    {
        Stop(Convert.ToInt32(id));
    }

    /// <summary>
    /// Will stop all audio on all channels.
    /// </summary>
    public void StopAll()
    {
        if (_channels.Count == 0)
            return;

        foreach (var channel in _channels)
            channel.Value.Clear(false);
    }
    #endregion


    #region IsAlreadyPlaying
    /// <summary>
    /// Checks if a specific sound is currently playing on the specified channel ID.
    /// </summary>
    /// <param name="id">The unique ID of the channel to check.</param>
    /// <param name="sound">The sound to check for on the specified channel.</param>
    /// <returns>True if the sound is currently playing on the specified channel ID; false otherwise.</returns>
    public static bool IsAlreadyPlaying(int id, Sound sound)
    {
        if (!Instance.TryGet(id, out var channel))
            return false;

        return channel.IsAlreadyPlaying(sound);
    }

    /// <summary>
    /// Checks if a specific sound is currently playing on the specified channel ID.
    /// </summary>
    /// <param name="id">The unique ID of the channel to check.</param>
    /// <param name="sound">The sound to check for on the specified channel.</param>
    /// <returns>True if the sound is currently playing on the specified channel ID; false otherwise.</returns>
    public static bool IsAlreadyPlaying(Enum id, Sound sound)
        => IsAlreadyPlaying(Convert.ToInt32(id), sound);

    #endregion


    #region Engine
    internal void EngineClear()
    {
        if (_channels.Count == 0)
            return;

        foreach (var channel in _channels)
            channel.Value.Clear(true);

        _channels.Clear();
    }
    #endregion
}
